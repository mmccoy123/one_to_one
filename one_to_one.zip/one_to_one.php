<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>One to One</title>
</head>
<body>
	<?php
		for( $i = 1; $i <= 1000; $i += 2) {
			echo $i . "<br>";
		}
	?>
</body>
</html>